import './models/categortdata.dart';

const categories_data = const [
  Categoretdata(
    id: 'c1',
    title: 'نجارة المنيوم ',
    imgurl: 'assets/images/alamino.jpg',
  ),
  Categoretdata(
    id: 'c2',
    title: 'نجار باطون ',
    imgurl: 'assets/images/baton.jpg',
  ),
  Categoretdata(
    id: 'c3',
    title: 'بلاط ',
    imgurl: 'assets/images/blat.jpg',
  ),
  Categoretdata(
    id: 'c4',
    title: 'معمرجي بلوك ',
    imgurl: 'assets/images/blok.jpg',
  ),
  Categoretdata(
    id: 'c5',
    title: 'دهان ',
    imgurl: 'assets/images/dhan.jpg',
  ),
  Categoretdata(
    id: 'c6',
    title: 'حداد حمايات ',
    imgurl: 'assets/images/drapzin.jpg',
  ),
  Categoretdata(
    id: 'c7',
    title: 'نجار خشب اثاث ',
    imgurl: 'assets/images/njar.jpg',
  ),
  Categoretdata(
    id: 'c8',
    title: 'سباك ',
    imgurl: 'assets/images/sback.jpg',
  ),
  Categoretdata(
    id: 'c7',
    title: 'طيان ',
    imgurl: 'assets/images/tina.jpg',
  ),
  Categoretdata(id: 'c8', title: 'كهربجي ', imgurl: 'assets/images/khrba.jpg')
];
