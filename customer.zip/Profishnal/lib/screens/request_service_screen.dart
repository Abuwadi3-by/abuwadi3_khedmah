import 'package:flutter/material.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/image_picker_botton.dart';
import '../models/order_model.dart';
import '/mock_order_data.dart';
import 'orders_screen.dart';

class RequestServiceScreen extends StatelessWidget {
  const RequestServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController titleController = TextEditingController();
    final TextEditingController locationController = TextEditingController();
    final TextEditingController descriptionController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text("طلب خدمة جديدة"),
        backgroundColor: const Color(0xFF00B4D8),
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            "تفاصيل الطلب",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 15),
          const Text("عنوان المشكلة",
              style: TextStyle(fontWeight: FontWeight.bold)),
          CustomTextField(
            hintText: "مثال: تسريب مياه في المطبخ",
            icon: Icons.title,
            controller: titleController,
          ),
          const SizedBox(height: 15),
          const Text("مكان المشكلة (العنوان)",
              style: TextStyle(fontWeight: FontWeight.bold)),
          CustomTextField(
            hintText: "مثال: دمشق - الميدان",
            icon: Icons.location_on,
            controller: locationController,
          ),
          const SizedBox(height: 15),
          const Text("شرح إضافي عن العطل",
              style: TextStyle(fontWeight: FontWeight.bold)),
          CustomTextField(
            hintText: "اكتب هنا تفاصيل المشكلة وما تحتاجه بالظبط...",
            icon: Icons.description,
            controller: descriptionController,
            maxLines: 4,
          ),
          const SizedBox(height: 20),
          const Text("صور العطل (اختياري)",
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const ImagePickerButton(),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () {
              if (titleController.text.isEmpty ||
                  locationController.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text("الرجاء ملء حقل العنوان والموقع")),
                );
                return;
              }

              OrderModel newOrder = OrderModel(
                id: DateTime.now().toString(),
                serviceName: titleController.text,
                location: locationController.text,
                date: "2026-06-02",
                status: "جاري استقبال العروض",
                statusColor: Colors.orange,
                offers: [],
              );

              MockOrdersData.addOrder(newOrder);

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const OrdersScreen(),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00B4D8),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              "نشر الطلب ",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
