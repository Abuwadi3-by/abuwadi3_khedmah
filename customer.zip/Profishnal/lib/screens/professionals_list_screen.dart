import 'package:flutter/material.dart';
import '../widgets/professional_card.dart';
import '../models/mock_workers_data.dart';

class ProfessionalsListScreen extends StatefulWidget {
  const ProfessionalsListScreen({super.key});

  @override
  State<ProfessionalsListScreen> createState() =>
      _ProfessionalsListScreenState();
}

class _ProfessionalsListScreenState extends State<ProfessionalsListScreen> {
  List<Map<String, String>> displayedWorkers = [];

  @override
  void initState() {
    super.initState();

    displayedWorkers = MockWorkersData.allWorkers;
  }

  void filterWorkers(String query) {
    setState(() {
      if (query.isEmpty) {
        displayedWorkers = MockWorkersData.allWorkers;
      } else {
        displayedWorkers = MockWorkersData.allWorkers
            .where((worker) =>
                worker["name"]!.contains(query) ||
                worker["job"]!.contains(query))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("المهنيين المتاحين"),
        backgroundColor: const Color(0xFF00B4D8),
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              onChanged: (value) => filterWorkers(value),
              decoration: InputDecoration(
                hintText: "ابحث عن مهني أو مهنة...",
                prefixIcon: const Icon(Icons.search, color: Color(0xFF00B4D8)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Color(0xFF00B4D8)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: Color(0xFF00B4D8), width: 2),
                ),
              ),
            ),
          ),
          Expanded(
            child: displayedWorkers.isEmpty
                ? const Center(
                    child: Text(
                      "لم يتم العثور على نتائج",
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    itemCount: displayedWorkers.length,
                    itemBuilder: (context, index) {
                      return ProfessionalCard(
                        name: displayedWorkers[index]["name"]!,
                        job: displayedWorkers[index]["job"]!,
                        rate: displayedWorkers[index]["rate"]!,
                        onTap: () {
                          print(
                              "تفاصيل المهني: ${displayedWorkers[index]["name"]}");
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
