import 'package:flutter/material.dart';
import '../widgets/chat_bubble.dart';

class ChatScreen extends StatefulWidget {
  final String workerName;

  const ChatScreen({super.key, required this.workerName});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _chatController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<Map<String, dynamic>> _messages = [
    {
      "message": "مرحباً معلم، شفت العرض تبعك ومناسبني",
      "type": "text",
      "isMe": true
    },
    {
      "message":
          "أهلاً بك يا غالي، تكرم عينك أنا جاهز. ممكن تبعتلي صورة العطل لتشوف شو بيلزمني موادوعدة ؟",
      "type": "text",
      "isMe": false
    },
    {"message": "صورة مكان التسريب تحت المغسلة", "type": "image", "isMe": true},
    {"message": "", "type": "audio", "isMe": false},
  ];

  void _sendMessage(String text, String type) {
    if (text.isEmpty && type == 'text') return;
    setState(() {
      _messages.add({
        "message": text,
        "type": type,
        "isMe": true,
      });
    });
    _chatController.clear();

    // ✅ سكرول للأسفل بعد الإرسال
    Future.delayed(const Duration(milliseconds: 100), () {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.white24,
              child: Text(widget.workerName[0],
                  style: const TextStyle(color: Colors.white)),
            ),
            const SizedBox(width: 10),
            Text(widget.workerName),
          ],
        ),
        backgroundColor: const Color(0xFF00B4D8),
        foregroundColor: Colors.white,
      ),
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(10),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final msg = _messages[index];
                  return ChatBubble(
                    message: msg["message"],
                    type: msg["type"],
                    isMe: msg["isMe"],
                  );
                },
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(
                // ✅ بدّلنا color بـ decoration عشان نضيف shadow
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  IconButton(
                    icon:
                        const Icon(Icons.camera_alt, color: Color(0xFF00B4D8)),
                    onPressed: () =>
                        _sendMessage("تم إرفاق صورة من الموقع", "image"),
                  ),
                  IconButton(
                    icon: const Icon(Icons.mic, color: Color(0xFF00B4D8)),
                    onPressed: () => _sendMessage("", "audio"),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _chatController,
                      decoration: InputDecoration(
                        hintText: "اكتب رسالة...",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                          borderSide: BorderSide.none,
                        ),
                        fillColor: Colors.grey[100],
                        filled: true,
                        contentPadding:
                            const EdgeInsets.symmetric(horizontal: 15),
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  CircleAvatar(
                    backgroundColor: const Color(0xFF00B4D8),
                    child: IconButton(
                      icon:
                          const Icon(Icons.send, color: Colors.white, size: 18),
                      onPressed: () =>
                          _sendMessage(_chatController.text, "text"),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
