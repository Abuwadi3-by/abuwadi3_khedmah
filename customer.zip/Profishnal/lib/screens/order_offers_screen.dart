import 'package:flutter/material.dart';
import '../widgets/offer_card1.dart';
import '../models/order_model.dart';

class OrderOffersScreen extends StatefulWidget {
  final OrderModel order;

  const OrderOffersScreen({super.key, required this.order});

  @override
  State<OrderOffersScreen> createState() => _OrderOffersScreenState();
}

class _OrderOffersScreenState extends State<OrderOffersScreen> {
  @override
  Widget build(BuildContext context) {
    final activeOffers = widget.order.offers;

    bool isAnyOfferAccepted = activeOffers.any((o) => o.isAccepted);

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: Text(
          "عروض لطلب: ${widget.order.serviceName}",
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF00B4D8),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: activeOffers.isEmpty
          ? const Center(
              child: Text(
                "لا توجد عروض نشطة حالياً لهذا الطلب",
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold),
              ),
            )
          : ListView.builder(
              itemCount: activeOffers.length,
              padding: const EdgeInsets.only(top: 10, bottom: 20),
              itemBuilder: (context, index) {
                final offer = activeOffers[index];

                return OfferCard(
                  offer: offer,
                  isAnyOfferAccepted: isAnyOfferAccepted,
                  onAccept: () {
                    setState(() {
                      offer.isAccepted = true;
                      widget.order.status = "قيد التنفيذ";
                      widget.order.statusColor = Colors.green;
                    });

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                            "تم قبول عرض المهني ${offer.workerName} بدء العمل!"),
                        backgroundColor: Colors.green,
                      ),
                    );
                  },
                  onReject: () {
                    setState(() {
                      activeOffers.removeAt(index);
                    });

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("تم رفض العرض وإزالته من القائمة."),
                        backgroundColor: Colors.redAccent,
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
