import 'package:flutter/material.dart';
import '/mock_order_data.dart';
import '../widgets/order_card.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  @override
  Widget build(BuildContext context) {
    final orders = MockOrdersData.ordersList;

    return Scaffold(
      appBar: AppBar(
        title: const Text("طلباتي وعروضي"),
        backgroundColor: const Color(0xFF00B4D8),
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: orders.isEmpty
          ? const Center(
              child: Text("لا يوجد لديك طلبات حالياً",
                  style: TextStyle(fontSize: 18, color: Colors.grey)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(15),
              itemCount: orders.length,
              itemBuilder: (context, index) {
                return OrderCard(
                  order: orders[index],
                  onRefresh: () {
                    setState(() {});
                  },
                );
              },
            ),
    );
  }
}
