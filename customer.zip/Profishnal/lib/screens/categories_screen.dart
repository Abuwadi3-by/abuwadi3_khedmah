import 'package:flutter/material.dart';

import '../app_data.dart';
import '../widgets/Catiegores_itm.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('تصنيفات المهنيين المتاحة '),
      ),
      body: GridView(
        padding: EdgeInsets.all(10),
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          childAspectRatio: 7 / 8,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
        ),
        children: categories_data
            .map((categoreedata) =>
                CatiegoresItm(categoreedata.title, categoreedata.imgurl))
            .toList(),
      ),
    );
  }
}
