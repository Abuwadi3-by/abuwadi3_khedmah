import 'package:flutter/material.dart';
import '../widgets/logo_widget.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // عرض الشعار
          LogoWidget(path: 'assets/images/logo.png', size: 300),

          SizedBox(height: 50),

          // زر الدخول برقم الهاتف
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: Icon(Icons.phone, color: Colors.white),
              label: Text("تسجيل الدخول برقم الهاتف"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF00B4D8),
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),

          SizedBox(height: 15),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: OutlinedButton.icon(
              onPressed: () {},
              icon: Icon(Icons.login, color: Color(0xFF00B4D8)),
              label: Text("تسجيل الدخول بواسطة جوجل"),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: Color(0xFF00B4D8)),
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
