import 'package:flutter/material.dart';
import 'package:untitled2/screens/orders_screen.dart';
import '../widgets/home_botton.dart';
import '../screens/request_service_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/categories_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                            icon: Icon(Icons.notifications_none,
                                color: Colors.cyan),
                            onPressed: () {}),
                        IconButton(
                            icon: Icon(Icons.chat_bubble_outline,
                                color: Colors.cyan),
                            onPressed: () {}),
                      ],
                    ),
                    CircleAvatar(
                      backgroundColor: Colors.cyan,
                      radius: 20,
                      child: Icon(Icons.home, color: Colors.white),
                    ),
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Image.asset(
                  'assets/images/logo.png',
                  height: 200,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  children: [
                    HomeButton(
                        title: "استعراض مهنيين",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const CategoriesScreen()),
                          );
                        }),
                    HomeButton(
                        title: "اطلب خدمة",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const RequestServiceScreen()),
                          );
                        }),
                    HomeButton(
                        title: "الطلب والعروض",
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const OrdersScreen()));
                        }),
                    HomeButton(
                        title: "الملف الشخصي",
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const ProfileScreen()),
                          );
                        }),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
