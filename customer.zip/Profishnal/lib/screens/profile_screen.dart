import 'package:flutter/material.dart';
import '../models/mock_profile_data.dart';
import '../widgets/profile_menu_item.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final user = MockProfileData.userProfile;

    return Scaffold(
      appBar: AppBar(
        title: const Text("الملف الشخصي"),
        backgroundColor: const Color(0xFF00B4D8),
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(
            child: Column(
              children: [
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: const Color(0xFF00B4D8).withOpacity(0.2),
                      child: const Icon(Icons.person,
                          size: 60, color: Color(0xFF00B4D8)),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: Color(0xFF00B4D8),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.camera_alt,
                            size: 16, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 15),
                Text(
                  user.name,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 5),
                Text(
                  user.email,
                  style: TextStyle(color: Colors.grey[600], fontSize: 14),
                ),
                const SizedBox(height: 5),
                Text(
                  user.phone,
                  style: TextStyle(color: Colors.grey[600], fontSize: 14),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Text(
            "الحساب والإعدادات",
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          const SizedBox(height: 10),
          ProfileMenuItem(
            icon: Icons.edit_outlined,
            title: "تعديل معلومات الحساب",
            onTap: () {
              print("الانتقال لصفحة تعديل البيانات");
            },
          ),
          ProfileMenuItem(
            icon: Icons.history,
            title: "أرشيف الطلبات السابقة",
            onTap: () {
              print("الانتقال للأرشيف");
            },
          ),
          ProfileMenuItem(
            icon: Icons.settings_outlined,
            title: "إعدادات التطبيق",
            onTap: () {
              print("فتح الإعدادات");
            },
          ),
          const Divider(height: 30),
          ProfileMenuItem(
            icon: Icons.logout,
            title: "تسجيل الخروج",
            textColor: Colors.red,
            onTap: () {
              print("تسجيل الخروج");
            },
          ),
        ],
      ),
    );
  }
}
