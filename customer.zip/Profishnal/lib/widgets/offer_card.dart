import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../screens/chat_screen.dart';

class OfferCard extends StatefulWidget {
  final OfferModel offer;
  final VoidCallback onAccept;

  const OfferCard({
    super.key,
    required this.offer,
    required this.onAccept,
  });

  @override
  State<OfferCard> createState() => _OfferCardState();
}

class _OfferCardState extends State<OfferCard> {
  bool _isThisOfferAccepted = false;

  @override
  Widget build(BuildContext context) {
    if (widget.offer.daysLeft <= 0) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 1),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                widget.offer.workerName,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  "متبقي: ${widget.offer.daysLeft} أيام",
                  style: TextStyle(
                      color: Colors.red[700],
                      fontSize: 12,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text("💰 السعر المعروض: ${widget.offer.price} ل.س",
              style: const TextStyle(fontSize: 15)),
          const SizedBox(height: 5),
          Text("⏳ مدة التنفيذ: ${widget.offer.duration}",
              style: const TextStyle(fontSize: 15, color: Colors.grey)),
          const Divider(height: 25),
          SizedBox(
            width: double.infinity,
            child: _isThisOfferAccepted
                ? ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              ChatScreen(workerName: widget.offer.workerName),
                        ),
                      );
                    },
                    icon: const Icon(Icons.chat),
                    label: const Text("عرض المحادثة (نشط)",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  )
                : ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _isThisOfferAccepted = true;
                      });
                      widget.onAccept();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00B4D8),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text("قبول العرض",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
          ),
        ],
      ),
    );
  }
}
