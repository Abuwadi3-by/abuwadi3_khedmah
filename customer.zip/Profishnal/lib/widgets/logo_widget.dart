import 'package:flutter/material.dart';

class LogoWidget extends StatelessWidget {
  final String path;
  final double size;

  LogoWidget({required this.path, this.size = 200});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Image.asset(
        path,
        width: size,
        height: size,
      ),
    );
  }
}
