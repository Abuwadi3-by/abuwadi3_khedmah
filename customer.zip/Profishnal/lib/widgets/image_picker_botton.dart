import 'package:flutter/material.dart';

class ImagePickerButton extends StatefulWidget {
  const ImagePickerButton({super.key});

  @override
  State<ImagePickerButton> createState() => _ImagePickerButtonState();
}

class _ImagePickerButtonState extends State<ImagePickerButton> {
  bool isImageSelected = false;

  void _showOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: [
              const ListTile(
                title: Text("إضافة صورة للعطل",
                    style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              ListTile(
                leading:
                    const Icon(Icons.photo_library, color: Color(0xFF00B4D8)),
                title: const Text("اختيار من معرض الصور (الاستوديو)"),
                onTap: () {
                  setState(() => isImageSelected = true);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.camera_alt, color: Color(0xFF00B4D8)),
                title: const Text("التقاط صورة بواسطة الكاميرا"),
                onTap: () {
                  setState(() => isImageSelected = true);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => _showOptions(context),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: isImageSelected ? Colors.green[50] : Colors.grey[100],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isImageSelected ? Colors.green : Colors.grey[300]!,
            width: 1.5,
          ),
        ),
        child: Column(
          children: [
            Icon(
              isImageSelected
                  ? Icons.check_circle
                  : Icons.cloud_upload_outlined,
              size: 35,
              color: isImageSelected ? Colors.green : const Color(0xFF00B4D8),
            ),
            const SizedBox(height: 8),
            Text(
              isImageSelected
                  ? "تم إرفاق الصورة بنجاح!"
                  : "اضغط هنا لإرفاق صورة أو التقاطها",
              style: TextStyle(
                color: isImageSelected ? Colors.green[700] : Colors.grey[600],
                fontWeight:
                    isImageSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
