import 'package:flutter/material.dart';

class ChatBubble extends StatelessWidget {
  final String message;
  final String type;
  final bool isMe;

  const ChatBubble({
    super.key,
    required this.message,
    required this.type,
    required this.isMe,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isMe ? const Color(0xFF00B4D8) : Colors.grey[200],
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(15),
            topRight: const Radius.circular(15),
            bottomLeft: Radius.circular(isMe ? 15 : 0),
            bottomRight: Radius.circular(isMe ? 0 : 15),
          ),
        ),
        child: _buildBubbleContent(),
      ),
    );
  }

  Widget _buildBubbleContent() {
    if (type == 'audio') {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.play_arrow, color: isMe ? Colors.white : Colors.black87),
          const SizedBox(width: 8),
          Text(
            "رسالة صوتية (0:12) 🎙️",
            style: TextStyle(color: isMe ? Colors.white : Colors.black87),
          ),
        ],
      );
    } else if (type == 'image') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 180,
            height: 120,
            decoration: BoxDecoration(
              color: isMe ? Colors.white24 : Colors.grey[400],
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.image, size: 50, color: Colors.white),
          ),
          const SizedBox(height: 5),
          Text(
            message,
            style: TextStyle(
                color: isMe ? Colors.white : Colors.black87, fontSize: 12),
          ),
        ],
      );
    } else {
      return Text(
        message,
        style: TextStyle(
          color: isMe ? Colors.white : Colors.black87,
          fontSize: 16,
        ),
      );
    }
  }
}
