import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../screens/order_offers_screen.dart';

class OrderCard extends StatelessWidget {
  final OrderModel order;
  final VoidCallback onRefresh;

  const OrderCard({
    super.key,
    required this.order,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(25.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  order.serviceName,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: order.statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    order.status,
                    style: TextStyle(
                        color: order.statusColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              "📍 الموقع: ${order.location}",
              style: const TextStyle(color: Colors.grey, fontSize: 14),
            ),
            const SizedBox(height: 5),
            Text(
              "📅 تاريخ الطلب: ${order.date}",
              style: const TextStyle(color: Colors.grey, fontSize: 14),
            ),
            const Divider(height: 25),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.local_offer_outlined,
                        color: Color(0xFF00B4D8)),
                    const SizedBox(width: 5),
                    Text(
                      order.offers.any((o) => o.daysLeft > 0)
                          ? "وصلك ${order.offers.where((o) => o.daysLeft > 0).length} عروض"
                          : "لا يوجد عروض نشطة",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: order.offers.any((o) => o.daysLeft > 0)
                            ? const Color(0xFF00B4D8)
                            : Colors.grey,
                      ),
                    ),
                  ],
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => OrderOffersScreen(order: order),
                      ),
                    ).then((value) {
                      onRefresh();
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00B4D8),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text("التفاصيل"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
