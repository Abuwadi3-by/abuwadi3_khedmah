import 'package:flutter/material.dart';
import 'models/order_model.dart';

class MockOrdersData {
  static List<OrderModel> ordersList = [
    OrderModel(
      id: "1",
      serviceName: "تصليح عطل كهربائي",
      location: "دمشق - مشروع دمر",
      date: "2026-06-16",
      status: "جاري استقبال العروض",
      statusColor: Colors.orange,
      offers: [
        OfferModel(
          workerName: "سامر العلي",
          price: 150000,
          duration: "ساعتين",
          createdAt: DateTime.now().subtract(const Duration(hours: 2)),
        ),
        OfferModel(
          workerName: "أحمد المحمد",
          price: 130000,
          duration: "خلال اليوم",
          createdAt: DateTime.now().subtract(const Duration(hours: 4)),
        ),
      ],
    ),
    OrderModel(
      id: "2",
      serviceName: "دهان غرفة الجلوس",
      location: "حمص - المحطة",
      date: "2026-06-16",
      status: "مكتمل",
      statusColor: Colors.green,
      offers: [],
    ),
  ];

  static void addOrder(OrderModel newOrder) {
    ordersList.add(newOrder);
  }
}
