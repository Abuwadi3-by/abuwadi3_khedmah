import 'package:flutter/material.dart';

class HomeMenuItem {
  final String title;
  final IconData icon;

  HomeMenuItem({required this.title, required this.icon});
}
