import 'package:flutter/material.dart';

// موديل العرض التجريبي عشان الشاشة تقرأه
class OfferModel {
  final String workerName;
  final double price;
  final String duration;
  final DateTime createdAt;
  bool isAccepted;

  OfferModel({
    this.isAccepted = false,
    required this.workerName,
    required this.price,
    required this.duration,
    required this.createdAt,
  });

  int get daysLeft {
    final expiryDate = createdAt.add(const Duration(days: 7));
    final difference = expiryDate.difference(DateTime.now()).inDays;
    return difference > 0 ? difference : 0;
  }
}

class OrderModel {
  final String id;
  final String serviceName;
  final String location;
  final String date;
  String status;
  List<OfferModel> offers;
  Color statusColor;

  OrderModel({
    required this.id,
    required this.serviceName,
    required this.location,
    required this.date,
    required this.status,
    required this.offers,
    required this.statusColor,
  });
}
