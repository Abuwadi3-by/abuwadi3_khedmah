class ProfileModel {
  String name;
  String email;
  String phone;

  ProfileModel({
    required this.name,
    required this.email,
    required this.phone,
  });
}

class MockProfileData {
  // بيانات المستخدم الحالية (تجريبية)
  static ProfileModel userProfile = ProfileModel(
    name: "خالد العبد الله",
    email: "khaled.abdallah@email.com",
    phone: "0933123456",
  );
}
