class Categoretdata {
  final String id;
  final String title;
  final String imgurl;

  const Categoretdata(
      {required this.id, required this.title, required this.imgurl});
}
