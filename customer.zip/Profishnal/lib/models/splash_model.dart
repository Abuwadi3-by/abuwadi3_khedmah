class SplashData {
  final String title;
  final String subtitle;
  final String logoPath;

  SplashData(
      {required this.title, required this.subtitle, required this.logoPath});
}
