class MockWorkersData {
  static final List<Map<String, String>> allWorkers = [
    {"name": "أحمد المحمد", "job": "كهربائي منازل", "rate": "4.8"},
    {"name": "سامر العلي", "job": "سباك (صحية)", "rate": "4.5"},
    {"name": "خالد الحمصي", "job": "دهان وديكور", "rate": "4.9"},
    {"name": "محمد الرفاعي", "job": "فني تكييف", "rate": "4.7"},
  ];
}
